//Programmer Name:94
//This file print out hospital name and set value to hosname
//Used in selection button 

<?php
include 'connecttodb.php';
$query = "SELECT DISTINCT hosname FROM hospital";
$result = mysqli_query($connection,$query);
if (!$result) {
die("databases query failed.");
}
while ($row = mysqli_fetch_assoc($result)) {
 echo "<option value='".$row["hosname"] ."'>";
 echo $row["hosname"];
 echo "</option>";
}
mysqli_free_result($result);
?>

