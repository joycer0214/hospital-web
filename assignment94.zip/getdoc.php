//Programmer Name: 94
//This file print out doctor's first and last name and set value to license number 
// Used	in select button 

<?php
include 'connecttodb.php';
$query = "SELECT * FROM doctor";
$result = mysqli_query($connection,$query);
if (!$result) {
die("databases query failed.");
}
while ($row = mysqli_fetch_assoc($result)) {
 echo "<option value='".$row["licensenum"] ."'>";
 echo $row["firstname"]." ".$row["lastname"];
 echo "</option>";
}
mysqli_free_result($result);
?>