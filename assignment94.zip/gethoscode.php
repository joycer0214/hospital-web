
<?php

$hoscode2 = $_POST['pickcode']; //get selected hospital from the form
echo "$hoscode2";
$query = "SELECT * FROM hospital WHERE hoscode='$hoscode1'";
echo "<br>" . $query . "<br>"; //this line is just to help you debug
$result = mysqli_query($connection, $query);
if (!$result) {
die("databases query on hospital failed. ");
}if(mysqli_num_rows($result)==0){
die("Hospital $hospital does not in system, please try again");
}
else{
header('Location:hospital.php');
}
exit;
?>