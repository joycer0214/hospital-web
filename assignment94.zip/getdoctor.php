//Programmer Name:94
//This file print out all the doctor's information

<?php

$button1 = $_POST["arrange"];
$button2 = $_POST["sort"];

$query = "SELECT * FROM doctor ORDER BY $button1 $button2";

include 'connecttodb.php';

$result = mysqli_query($connection, $query);

if (!$result) {
 die("databases query failed.");
}

echo " <table border=\"5\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#808080\" width=\"100&#37;\"   $
   <tr>
   <td width=100>Doctor license number </td>
  <td width=100>First name</td>
  <td width=100>Last name</td>
  <td width=100>License date</td>
  <td width=100>Birthdate</td>
  <td width=100>Hospital works at</td>
  <td width=100>Speciality</td>
  </tr>";


while($row = mysqli_fetch_assoc($result)){
print "<tr>";
print "<td>" . $row['licensenum'] . "</td>";
print "<td>" . $row['firstname'] . "</td>";
print "<td>" . $row['lastname'] . "</td>";
print "<td>" . $row['licensedate'] . "</td>";
print "<td>" . $row['birthdate'] . "</td>";
print "<td>" . $row['hosworksat'] . "</td>";
print "<td>" . $row['speciality'] . "</td>";
print "</td>";
}
mysqli_free_result($result);

?>