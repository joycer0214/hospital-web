<?php
$doccode = $_POST['doccode'];
$liccode = $_POST['liccode'];

include 'connecttodb.php';

if($doccode != $liccode && $liccode != '1' && $doccode != NULL){
 echo '<script> alert("Choose only one doctor");';
 echo 'window.location.href = "thesystem.php";';
 echo '</script>';
}

if($doccode == NULL){
 $doccode = $liccode;
}

$query1 = "SELECT * FROM doctor WHERE licensenum = '$doccode'";
$check_result = mysqli_query($connection,$query1);

if(!$check_result){
die("Error: doctor check failed".mysqli_error($connection));
}
if(mysqli_num_rows($check_result)==0){
echo '<script> alert("Doctor does not exit.");';
echo 'window.location.href = "thesystem.php";';
echo '</script>';
}

$query = "DELETE FROM doctor WHERE licensenum = '$doccode'";
$result = mysqli_query($connection,$query);

if(mysqli_connect_errno()){
echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

if(!$result){
echo '<script> alert("Error description: Can not delete doctor.");';
echo 'window.location.href = "thesystem.php";';
echo '</script>';
}else{
 echo "<br> Doctor information is succesfully deleted.";
}

mysqli_close($connection);

?>






