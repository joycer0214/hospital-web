<?php
include 'connecttodb.php';
$doctor = $_POST['doctor'];
$patient = $_POST['patient'];

$query = 'INSERT INTO looksafter values("'.$doctor.'","'.$patient.'")';
$result = mysqli_query($connection,$query);

echo "$num";
if(mysqli_connect_errno()){
 die("Connection failed");
}

if(!$result){
 echo '<script> alert("Patient already been assigned to Doctor.");';
 echo 'window.location.href = "thesystem.php";';
 echo '</script>';
}else{
 echo '<script> alert("Patient has been assigned.");';
 echo 'window.location.href = "thesystem.php";';
 echo '</script>';
}

mysqli_close($connection);


?>

