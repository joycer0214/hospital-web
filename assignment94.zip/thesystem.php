<!-- Programmer Name:94 -->

<!DOCTYPE html>
<html>
<head>
<style>
body{
background-color: lightblue;
}
h1{
 text-align:center;
}
h2{
 text-align:center;
}

<title> hospital system</title>
<link rel="stylesheet" type="text/css" href="hospital.css">
<link href="https://fonts.googleapis.com/css?family=Mali"
rel="stylesheet">
<script>
function confirmact(){
 let confirmact = confirm("Are you sure you want to delete this doctor?");
 if(confirmact == true){
 let form=document.getElementById("");
 form.submit();
 }else{
}
}
</style>
</script>
</head>

//connect to database
<body>
<?php
include 'connecttodb.php';
?>

<h1> Hospital system</h1>

<!--Get doctor's information by selected order -->

<form action = "getdoctor.php" method="POST" >
<h3> How do you want to arrange the doctor information:</h3>
<lable>
<input type = "radio" id="lastname"  name="arrange" value ="lastname">Last Name</label><br>
<lable>
<input type = "radio" id= "bday"  name="arrange" value ="birthdate"> Birthday</label><br>
<br>

<h3> Please select a order method:</h3>
<lable>
<input type = "radio" id="asc" name="sort" value ="ASC"> Ascending</label><br>
<label>
<input type = "radio" id="desc" name="sort" value ="DESC">Descending</label><br>
<br>
<input type="submit" name= "submit" value="Set">
</form>

<p>
<hr>
<p>

<!-- Allow the user to select one of the specialties and then list all the doctor information about just doctors with this specialty. Your code should only list the specialties that currently exist in the doctor table.-->

<h2> Select doctor by speciality</h2>
<form action = "getdoctorbyspe.php" method="POST" >
<h3> Please select a specialty:</h3>
<label>
<input type="radio" id="uro" name = "speciality" value = "Urologist"</label>Urologist<br>
<label>
<input type="radio" id="pod" name = "speciality" value = "Podiatrist"</label>Podiatrist<br>
<label>
<input type="radio" id="surg" name = "speciality" value = "Surgeon"</label>Surgeon<br>
<input type="submit" name= "submit" value="Submit">
</form>

<br>

<p>
<hr>
<p>

<!-- Insert a new doctor. Prompt for the necessary data.  The user may type in the hospital code directly or pick from a list of hospitals. -->
<h2> Add new doctor</h2>
<p>
<form action = "addnewdoc.php" method="post">
Doctor's First Name:<input type="text" name="docfname" maxlength="20">
Last Name<input type="text" name="doclname" maxlength="20"><br>

<label>
Doctor's license number:<input type = "text" name= "docln" maxlength="4"><br>
<span class="validity">
</label>

<label for="licensedate">Doctor's license date:</label>
<input type="date" name="ldate" min="1800-01-01" max="2023-01-01">

<br>

<label for="Birthdate">Doctor's Birthdate:</label>
<input type="date" name="bdate" min="1800-01-01" max="2023-01-01">
<br>

Doctor's speciality:<input type="text" name="spec" maxlength="30"><br>
<label>
Select or input an Hospital code:
<input type="text" name = "hoscode" maxlength="3">
<span class="validity">
</label>

<select name="pickcode" id="pickcode">
<option value = "1">Select Here</option>
<?php
include "gethos.php";
?>
</select>

<br>
<input type="submit">

</form>


<p>
<hr>
<p>

<!-- Delete an existing doctor. Either prompt for the doctor license number or you could display the list of doctors and allow the user to pick the one they want to delete. -->
<h2> Delete a doctor</h2>

<form action = "deletdoc.php" method="post" id= "deletact">

<label>
Doctor's licence number:<input type="text" name="doccode"><br>
</label>

<label>
Select a doctor:
<select name="liccode">
<option value="1">Select</option>
<?php
include "getdoc.php";
?>
</select>
</label>
<br>
<button onclick = "confirmact()">Delete</button>
</form>

<p>
<hr>
<p>

<!-- Assign a doctor to a patient. Do not allow this if the relationship already exists (output a warning like "Patient already assigned to this doctor"). Allow the user to select a doctor and a patient and then create the relationship.  -->

<h2> Assign new patient</h2>

<form action="asrelation.php" method="post">

<h3> Choose a doctor:</h3>
<select name="doctor">
<option value = "1"> Select Here</option>
<?php
include "getdoc.php";
?>
</select>

<h3> Choose a patient:</h3>
<select name="patient">
<option value = "1">Select Here</option>
<?php
include "getpatient.php";
?>
</select>

<input type="submit" value="Assign">
</form>

<p>
<hr>
<p>

<!-- Allow the user to select a doctor and see the first and last name and ohip number of any patient treated by that doctor. -->

<h2> Look through patient</h2>

<form action="patient.php" method="post">
<h3>Choose a doctor:</h3>
<Select name="doctors">
<option value="1">Select</option>
<?php
  include 'getdoc.php';
?>
</select>

<input type="submit" value="Look">
</form>


<p>
<hr>
<p>
<!-- Allow the user to select a hospital and display a hospital name, city, province, number of beds, and head doctor first and last name and then list all the doctors (first and last name) that work at that hospital.-->
<h2>Hospital information</h2>

<form action="hospital.php" method="post">
Choose a hospital:<select name="hospital">
<option value="1">Select</option>
<?php
include 'gethos.php';
?>
</select>

<!-- Allow the user to select a hospital and change (UPDATE) the number of beds at that hospital.-->
<br>
<lable for="numbed">Change number of beds</label>
<input type="number" name="update" min="0" max="5000">
<br>
<input type="submit" value="look" name="submit">
<input type="submit" value="change" name="change">
</form>



</body>
</html>

