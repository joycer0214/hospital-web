//Programmer Name:94
//Print patient first and last name set value to ohipnum

<?php
include'connecttodb.php';
$query = "SELECT * FROM patient";
$result = mysqli_query($connection, $query);
if(!$result){
die("database query failed.");
}
while($row = mysqli_fetch_assoc($result)){
 echo "<option value = '".$row["ohipnum"]."'>";
 echo $row["firstname"]." ".$row["lastname"];
 echo "</option>";
}
mysqli_free_result($result);

?>