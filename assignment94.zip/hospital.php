<?php
include 'connecttodb.php';
$hospital = $_POST['hospital'];
$numbed = $_POST['update'];
$submit = $_POST['submit'];
$change = $_POST['change'];

if(isset($submit)){
$query = "SELECT hosname, city,prov,numofbed,doctor.firstname,doctor.lastname,headdoc,licensenum FROM hospital INNER JOIN doctor ON hospital.hoscode = hosworksat and ho$

$result= mysqli_query($connection,$query);
if(!$result){
die("databases query failed.");
}

echo " <table border=\"5\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-  collapse: collapse\" bordercolor=\"#808080\" width=\"100&#37;\"    id=\"AutoNumber2\" bg$
   <tr>
   <td width=100>Hospital name</td>
  <td width=100>City</td>
  <td width=100>Province</td>
  <td width=100>Number of beds</td>
  <td width=100>Doctor</td>
  <td width=100>Head Doctors</td>
  </tr>";

while($row = mysqli_fetch_assoc($result)){
print "<tr>";
print "<td>" . $row['hosname'] . "</td>";
print "<td>" . $row['city'] . "</td>";
print "<td>" . $row['prov'] . "</td>";
print "<td>" . $row['numofbed'] . "</td>";
print "<td>" . $row['firstname'] ." ". $row['lastname']. "</td>";
if($row['headdoc']==$row['licensenum']){
 print "<td>" . $row['firstname'] ." ". $row['lastname']. "</td>";
}
print "</td>";
}
}

if(isset($change)){
$query = "UPDATE hospital SET numofbed = '$numbed' WHERE hoscode = '$hospital'";
$result= mysqli_query($connection,$query);
if(!$result){
die("databases query failed.");
}
echo "Information is updated successfully.";
}

mysqli_close($connection);
?>

