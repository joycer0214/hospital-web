
//Programmer Name:94
//This file print out patients info by doctor's license number

<?php
include 'connecttodb.php';
$doctor = $_POST['doctors'];

$query = "SELECT patient.firstname, patient.lastname, patient.ohipnum FROM looksafter INNER JOIN patient ON patient.ohipnum = looksafter.ohipnum and licensenum = '$doct$
$result= mysqli_query($connection,$query);
if(!$result){
die("databases query failed.");
}
echo " <table border=\"5\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse: collapse\"bordercolor=\"#808080\" width=\"100&#37;\"   $

   <tr>
  <td width=100>First name</td>
  <td width=100>Last name</td>
  <td width=100> OHIP number</td>
  </tr>";

while($row = mysqli_fetch_assoc($result)){
print "<tr>";
print "<td>" . $row['firstname'] . "</td>";
print "<td>" . $row['lastname'] . "</td>";
print "<td>" . $row['ohipnum'] . "</td>";
print "</td>";
}
mysqli_close($connection);
?>