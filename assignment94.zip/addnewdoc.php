//Programmer Name: 94
//This php file prossess insertion of doctor information
//Error message when user input two hospital code
//Error message when hospital does not exist
//Error message when user try to insert duplicate doctor


<?php

$fname = $_POST["docfname"];
$lname = $_POST['doclname'];
$licensenum = $_POST['docln'];

$ldate = $_POST['ldate'];
$bdate = $_POST['bdate'];

$special = $_POST['spec'];
$hoscode = $_POST['hoscode'];
$pickcode = $_POST['pickcode'];

include 'connecttodb.php';
//If user give two inputs shows eror message
if($hoscode!= NULL && $pickcode!== "1"){
 echo '<script> alert("Chose only one hospital code");';
 echo 'window.location.href = "thesystem.php";';
 echo '</script>';
}

if($hoscode==NULL){
 $hoscode = $pickcode;
}

$query = "SELECT hosname FROM hospital WHERE hoscode ='$hoscode'";
$result = mysqli_query($connection,$query);

if (!$result) {
die("Error: Query connection error" . mysqli_error($connection));
}

//Check if hospital is in database
if (mysqli_num_rows($result)==0){
 echo '<script> alert("Hospital does not in system, please try again.");';
 echo 'window.location.href = "thesystem.php";';
 echo '</script>';
}

//Check if doctor is in database
$query2 = "SELECT firstname,lastname FROM doctor WHERE licensenum ='$licensenum'";
$result2 = mysqli_query($connection,$query2);
if (!$result2) {
  die("Error: Query2 failed".mysqli_error($connection));
 }

if(mysqli_num_rows($result2)>0){
 echo '<script> alert("Doctor already in system.");';
 echo 'window.location.href = "thesystem.php";';
 echo '</script>';
}

//Query for doctor information insertion.
$query = "INSERT INTO doctor VALUES('$licensenum','$fname','$lname','$ldate','$bdate','$hoscode','$special');";
$result=mysqli_query($connection,$query);
if (!$result) {
 echo mysqli_error();
 }else{
echo '<script> alert(" Doctor information is succesfully added.");';
echo 'window.location.href = "thesystem.php";';
echo '</script>';
}

mysqli_close($connection);

?>
